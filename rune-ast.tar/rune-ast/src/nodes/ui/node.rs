use crate::Span;
use crate::logic::expr::Expr;
use super::{UiAttribute, UiModifier, UiText};

#[derive(Debug, Clone)]
pub enum UiNode {
    // XML-style <Tag ...>...</Tag>
    Element {
        name: String,
        attributes: Vec<UiAttribute>,
        modifiers: Vec<UiModifier>,
        control: Option<UiControl>,
        children: Vec<UiNodeOrExpr>,
        span: Span,
    },

    // BLOCK-style Tag { ... }
    BlockElement {
        name: String,
        attributes: Vec<UiAttribute>,
        modifiers: Vec<UiModifier>,
        control: Option<UiControl>,
        children: Vec<UiNodeOrExpr>,
        span: Span,
    },

    // XML-style <Tag ... />
    SelfClosing {
        name: String,
        attributes: Vec<UiAttribute>,
        modifiers: Vec<UiModifier>,
        span: Span,
    },

    // BLOCK-style self closing: Tag {}
    BlockSelfClosing {
        name: String,
        modifiers: Vec<UiModifier>,
        span: Span,
    },
}

impl UiNode {
    pub fn span(&self) -> Span {
        match self {
            UiNode::Element { span, .. } => *span,
            UiNode::BlockElement { span, .. } => *span,
            UiNode::SelfClosing { span, .. } => *span,
            UiNode::BlockSelfClosing { span, .. } => *span,
        }
    }
}

#[derive(Debug, Clone)]
pub enum UiNodeOrExpr {
    Node(UiNode),
    Text(UiText),
}

/// Inline control directive on a UI tag: `<Tag if{cond}>`, `<Tag for{x in xs}>`, `<Tag match{expr}>`.
/// Governs whether / how many times / which branch of the tag's children render.
#[derive(Debug, Clone)]
pub enum UiControl {
    If(Expr),
    For { binding: String, iter: Expr },
    Match(Expr),
}
