#[derive(Debug, Clone, Copy, PartialEq, Eq, Ord, PartialOrd)]
pub struct Position {
    /// Byte offset from the start of the file (UTF-8 aware, in bytes not characters)
    pub offset: usize,
    /// Line number (1-based indexing)
    pub line: usize,
    /// Column number (1-based indexing, UTF-8 aware for character width)
    pub column: usize,
}

impl Position {
    pub fn new(offset: usize, line: usize, column: usize) -> Self {
        Self { offset, line, column }
    }

    /// Creates a dummy position (line=0, column=0) for errors or nodes without source location
    pub fn dummy() -> Self {
        Position { offset: 0, line: 0, column: 0 }
    }

    /// Advances the position by a given number of bytes. Used by the lexer during tokenization.
    /// Note: assumes one character per call; the lexer is responsible for correct byte counting.
    pub fn advance_byte(&mut self, byte_len: usize) {
        self.offset += byte_len;
        self.column += 1; // Increment column for each character/token
    }

    /// Moves to a new line, incrementing line number and resetting column to 1
    pub fn new_line(&mut self) {
        self.line += 1;
        self.column = 1;
    }

    /// Returns true if this is a dummy position (line=0, column=0)
    pub fn is_dummy(&self) -> bool {
        self.line == 0 && self.column == 0
    }

    /// Returns a new position advanced by the given byte length, with column incremented by 1
    pub fn advanced(&self, byte_len: usize) -> Position {
        Position {
            offset: self.offset + byte_len,
            line: self.line,
            column: self.column + 1,
        }
    }

    /// Calculates the byte distance between two positions if they're on the same line.
    /// Returns None if positions are on different lines.
    pub fn distance_to(&self, other: Position) -> Option<usize> {
        if self.line == other.line {
            Some(other.offset.saturating_sub(self.offset))
        } else {
            None
        }
    }
}
