// Small output-capture buffer used by the `print`/`dbg` builtins (see
// call.rs). Native targets (the CLI, tests) keep seeing output on stdout
// exactly as before -- this buffer exists purely so a host embedding the
// evaluator with no real stdout (the wasm bridge, rune-wasm) can retrieve
// what a Rune program printed, by calling `take_output()` after a run.
use std::cell::RefCell;

thread_local! {
    static OUTPUT: RefCell<String> = RefCell::new(String::new());
}

/// Records one line of program output. On non-wasm targets this also
/// prints to stdout immediately, so existing CLI/test behavior is
/// unchanged.
pub fn emit(line: &str) {
    #[cfg(not(target_arch = "wasm32"))]
    println!("{}", line);

    OUTPUT.with(|o| {
        let mut o = o.borrow_mut();
        o.push_str(line);
        o.push('\n');
    });
}

/// Drains and returns everything emitted since the last call (or since
/// startup). Embedding hosts call this after running a program.
pub fn take_output() -> String {
    OUTPUT.with(|o| std::mem::take(&mut *o.borrow_mut()))
}
