use std::collections::HashMap;
use std::rc::Rc;
use crate::runtime::env::Env;
use crate::utils::errors::EvalError;
use crate::runtime::value::Value;
use crate::evaluator::eval_host::{EvalHost, Flow};
use rune_ast::{Expr, Block, Span, FnDecl};

pub struct HostVM {
    pub env: Env,
    pub functions: HashMap<String, FnDecl>,
    pub modules: HashMap<String, Value>,
}

impl HostVM {
    pub fn new() -> Self {
        Self {
            env: Env::new(),
            functions: HashMap::new(),
            modules: HashMap::new(),
        }
    }
}

impl EvalHost for HostVM {
    fn load_var(&mut self, name: &str, span: Span) -> Value {
        self.env.lookup(name).unwrap_or_else(|| {
            panic!("Undefined variable '{}' at {:?}", name, span)
        })
    }

    fn define_var(&mut self, name: &str, value: Value) {
        self.env.define(name, value);
    }

    fn push_scope(&mut self) { self.env.push(); }
    fn pop_scope(&mut self) { self.env.pop(); }

    fn eval_expr(&mut self, expr: &Expr) -> Value {
        crate::evaluator::eval_expr::eval_expr(self, expr)
    }

    fn eval_block(&mut self, block: &Block) -> Flow {
        let mut last = Value::Unit;
        for stmt in &block.stmts {
            match crate::evaluator::eval_stmt::eval_stmt(self, stmt) {
                Flow::Return(v) => return Flow::Return(v),
                Flow::Break => return Flow::Break,
                Flow::Continue => return Flow::Continue,
                Flow::Value(v) => last = v,
            }
        }
        Flow::Value(last)
    }

    fn assign_to(&mut self, lhs: &Expr, value: Value) -> bool {
        match lhs {
            Expr::Ident(name, _) => {
                self.set_var(name, value);
                true
            }
            Expr::Field { target, field, .. } => {
                let mut obj = self.eval_expr(target);
                obj.set_field(field, value);
                true
            }
            Expr::Index { target, index, .. } => {
                let mut arr = self.eval_expr(target);
                let idx = self.eval_expr(index).as_int();
                arr.set_index(idx, value);
                true
            }
            _ => false,
        }
    }

    fn call_fn(&mut self, name: &str, args: &[Value], span: Span) -> Result<Value, EvalError> {
        super::host_call::call_fn(self, name, args, span)
    }

    fn call_user_fn(&mut self, name: &str, args: &[Value], span: Span) -> Result<Value, EvalError> {
        super::host_call::call_user_fn(self, name, args, span)
    }

    fn call_value(&mut self, value: Value, args: &[Value], span: Span) -> Value {
        super::host_call::call_value(self, value, args, span)
    }

    fn set_var(&mut self, name: &str, value: Value) { self.env.set(name, value); }
    fn eval_block_flow(&mut self, block: &Block) -> Flow {
        crate::evaluator::eval_block::eval_block_flow(self, block)
    }

    fn bind_pattern(&mut self, pat: &rune_ast::Pattern, value: &Value) -> bool {
        super::host_pattern::bind_pattern(self, pat, value)
    }

    fn match_pattern(&mut self, value: &Value, pat: &rune_ast::Pattern) -> bool {
        super::host_pattern::match_pattern(self, value, pat)
    }

    fn namespace_lookup(&mut self, ns: Value, item: &str) -> Value {
        super::host_field::namespace_lookup(self, ns, item)
    }

    fn field_lookup(&mut self, obj: Value, field: &str) -> Value {
        super::host_field::field_lookup(self, obj, field)
    }

    fn index_lookup(&mut self, obj: Value, index: Value) -> Value {
        super::host_field::index_lookup(self, obj, index)
    }

    fn capture_env(&mut self) -> Rc<Env> {
        Rc::new(self.env.clone())
    }

    fn apply_compound(&mut self, left: &Value, op: &str, right: &Value) -> Value {
        super::host_field::apply_compound(self, left, op, right)
    }
}
