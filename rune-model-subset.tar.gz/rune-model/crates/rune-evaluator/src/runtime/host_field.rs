use crate::runtime::value::Value;
use super::host_vm::HostVM;

pub fn namespace_lookup(_host: &mut HostVM, ns: Value, item: &str) -> Value {
    match ns {
        Value::Namespace { items, .. } => {
            items.lookup(item).unwrap_or_else(|| {
                panic!("Unknown namespace item '{}'", item)
            })
        }
        _ => panic!("Value is not a namespace"),
    }
}

pub fn field_lookup(_host: &mut HostVM, obj: Value, field: &str) -> Value {
    match obj {
        Value::StructInstance { fields, .. } => {
            for (k, v) in fields {
                if k == field {
                    return v;
                }
            }
            panic!("No field '{}' found", field);
        }
        _ => panic!("Value is not an object"),
    }
}

pub fn index_lookup(_host: &mut HostVM, obj: Value, index: Value) -> Value {
    match (obj, index.as_number()) {
        (Value::List(list), Some(i)) => list[i as usize].clone(),
        _ => panic!("Invalid indexing"),
    }
}

pub fn apply_compound(_host: &mut HostVM, left: &Value, op: &str, right: &Value) -> Value {
    match (left, op, right) {
        (Value::Number(a), "+=", Value::Number(b)) => Value::Number(a + b),
        (Value::Number(a), "-=", Value::Number(b)) => Value::Number(a - b),
        (Value::Number(a), "*=", Value::Number(b)) => Value::Number(a * b),
        (Value::Number(a), "/=", Value::Number(b)) => Value::Number(a / b),
        // TODO: Add string/list/map compound assignments
        _ => Value::Unit,
    }
}
