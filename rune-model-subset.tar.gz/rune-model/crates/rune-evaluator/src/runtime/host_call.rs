use crate::utils::errors::{EvalError, EvalResult};
use crate::runtime::value::Value;
use crate::evaluator::eval_host::EvalHost;
use rune_ast::Span;
use super::host_vm::HostVM;

pub fn call_fn(host: &mut HostVM, name: &str, args: &[Value], span: Span) -> EvalResult<Value> {
    // Check builtins first
    if let Some(Value::HostFunction(func)) = host.modules.get(name) {
        return Ok(func(args.to_vec()));
    }

    // Try user-defined functions
    if let Some(f) = host.functions.get(name).cloned() {
        return Ok(crate::evaluator::eval_fn::eval_user_fn(host, &f, args, span));
    }

    Err(EvalError::InvalidOp {
        msg: format!("Unknown function '{}'", name),
        span,
    })
}

pub fn call_user_fn(host: &mut HostVM, name: &str, args: &[Value], span: Span) -> EvalResult<Value> {
    if let Some(f) = host.functions.get(name).cloned() {
        Ok(crate::evaluator::eval_fn::eval_user_fn(host, &f, args, span))
    } else {
        Err(EvalError::InvalidOp {
            msg: format!("Unknown user function '{}'", name),
            span,
        })
    }
}

pub fn call_value(host: &mut HostVM, value: Value, args: &[Value], span: Span) -> Value {
    match value {
        Value::HostFunction(func) => func(args.to_vec()),

        Value::Function { params, body, env, .. } => {
            host.push_scope();
            host.env.extend_from(&env);
            for (param, arg) in params.iter().zip(args.iter()) {
                host.define_var(param, arg.clone());
            }

            let result = match body {
                crate::evaluator::eval_fn::FnBodyKind::Block(b) =>
                    match host.eval_block(&b) {
                        crate::evaluator::eval_host::Flow::Value(v) | crate::evaluator::eval_host::Flow::Return(v) => v,
                        _ => Value::Unit,
                    },
                crate::evaluator::eval_fn::FnBodyKind::Expr(e) => host.eval_expr(&e),
            };

            host.pop_scope();
            result
        }

        Value::Lambda { params, body, closure } => {
            host.push_scope();
            host.env.extend_from(&closure);
            for (param, arg) in params.iter().zip(args.iter()) {
                host.define_var(param, arg.clone());
            }
            let v = host.eval_expr(&body);
            host.pop_scope();
            v
        }

        _ => panic!("Value is not callable at {:?}", span),
    }
}
