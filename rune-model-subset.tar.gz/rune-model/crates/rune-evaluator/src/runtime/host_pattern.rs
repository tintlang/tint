use crate::runtime::value::Value;
use rune_ast::{Pattern, PatternField};
use super::host_vm::HostVM;
use crate::evaluator::eval_host::EvalHost;

pub fn bind_pattern(host: &mut HostVM, pat: &Pattern, value: &Value) -> bool {
    match pat {
        Pattern::Wildcard(_) => true,
        Pattern::Ident(name, _) => {
            host.define_var(name, value.clone());
            true
        }
        Pattern::Number(n, _) => match value {
            Value::Number(v) => v.to_string() == *n,
            _ => false,
        },
        Pattern::String(s, _) => match value {
            Value::String(v) => v == s,
            _ => false,
        },
        Pattern::Mut { inner, .. } => match_pattern(host, value, inner),
        Pattern::Group { fields, .. } | Pattern::Map { fields, .. } => {
            if let Value::Map(map) = value {
                bind_pattern_fields(host, fields, &|field| map.get(field).cloned())
            } else {
                false
            }
        }
        Pattern::Tuple(p_items, _) => match value {
            Value::Tuple(v_items) if p_items.len() == v_items.len() => {
                p_items.iter().zip(v_items).all(|(p, v)| bind_pattern(host, p, v))
            }
            _ => false,
        },
        Pattern::Struct { name, fields, .. } => match value {
            Value::StructInstance { name: vname, fields: vfields } if vname == name => {
                bind_struct_fields(host, fields, vfields)
            }
            _ => false,
        },
        Pattern::Variant { name, args, .. } => match value {
            Value::EnumInstance { variant, args: v_args, .. } if variant == name && args.len() == v_args.len() => {
                args.iter().zip(v_args).all(|(p, v)| bind_pattern(host, p, v))
            }
            _ => false,
        },
        Pattern::Typed { pat, ty, .. } => {
            value.matches_type(ty) && bind_pattern(host, pat, value)
        }
    }
}

pub fn match_pattern(host: &mut HostVM, value: &Value, pat: &Pattern) -> bool {
    match pat {
        Pattern::Wildcard(_) => true,
        Pattern::Number(s, _) => match value {
            Value::Number(n) => n.to_string() == *s,
            _ => false,
        },
        Pattern::String(s, _) => match value {
            Value::String(v) => v == s,
            _ => false,
        },
        Pattern::Mut { inner, .. } => bind_pattern(host, inner, value),
        Pattern::Ident(_, _) => true,
        Pattern::Group { fields, .. } | Pattern::Map { fields, .. } => {
            if let Value::Map(map) = value {
                match_pattern_fields(host, fields, &|field| map.get(field))
            } else {
                false
            }
        }
        Pattern::Tuple(p_items, _) => match value {
            Value::Tuple(v_items) if p_items.len() == v_items.len() => {
                p_items.iter().zip(v_items).all(|(p, v)| match_pattern(host, v, p))
            }
            _ => false,
        },
        Pattern::Struct { name, fields, .. } => match value {
            Value::StructInstance { name: vname, fields: vfields } if vname == name => {
                match_struct_fields(host, fields, vfields)
            }
            _ => false,
        },
        Pattern::Variant { name, args, .. } => match value {
            Value::EnumInstance { variant, args: v_args, .. } if variant == name && args.len() == v_args.len() => {
                args.iter().zip(v_args).all(|(p, v)| match_pattern(host, v, p))
            }
            _ => false,
        },
        Pattern::Typed { pat, ty, .. } => {
            value.matches_type(ty) && match_pattern(host, value, pat)
        }
    }
}

fn bind_pattern_fields<F>(host: &mut HostVM, fields: &[PatternField], getter: &F) -> bool
where
    F: Fn(&str) -> Option<Value>,
{
    for pf in fields {
        match pf {
            PatternField::Shorthand { field, .. } => {
                let Some(v) = getter(field) else { return false };
                host.define_var(field, v);
            }
            PatternField::Assign { field, pat, .. } => {
                let Some(v) = getter(field) else { return false };
                if !bind_pattern(host, pat, &v) {
                    return false;
                }
            }
            PatternField::Rest(_) => {}
        }
    }
    true
}

fn match_pattern_fields<'a, F>(host: &mut HostVM, fields: &[PatternField], getter: &F) -> bool
where
    F: Fn(&str) -> Option<&'a Value>,
{
    for pf in fields {
        match pf {
            PatternField::Shorthand { field, .. } => {
                if getter(field).is_none() {
                    return false;
                }
            }
            PatternField::Assign { field, pat, .. } => {
                let Some(v) = getter(field) else { return false };
                if !match_pattern(host, v, pat) {
                    return false;
                }
            }
            PatternField::Rest(_) => {}
        }
    }
    true
}

fn bind_struct_fields(host: &mut HostVM, pat_fields: &[PatternField], val_fields: &[(String, Value)]) -> bool {
    for pf in pat_fields {
        match pf {
            PatternField::Shorthand { field, .. } => {
                let Some((_, v)) = val_fields.iter().find(|(k, _)| k == field) else { return false };
                host.define_var(field, v.clone());
            }
            PatternField::Assign { field, pat, .. } => {
                let Some((_, v)) = val_fields.iter().find(|(k, _)| k == field) else { return false };
                if !bind_pattern(host, pat, v) {
                    return false;
                }
            }
            PatternField::Rest(_) => {}
        }
    }
    true
}

fn match_struct_fields(host: &mut HostVM, pat_fields: &[PatternField], val_fields: &[(String, Value)]) -> bool {
    for pf in pat_fields {
        match pf {
            PatternField::Shorthand { field, .. } => {
                if !val_fields.iter().any(|(k, _)| k == field) {
                    return false;
                }
            }
            PatternField::Assign { field, pat, .. } => {
                let Some((_, v)) = val_fields.iter().find(|(k, _)| k == field) else { return false };
                if !match_pattern(host, v, pat) {
                    return false;
                }
            }
            PatternField::Rest(_) => {}
        }
    }
    true
}
