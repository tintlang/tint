// rune-evaluator/eval_block.rs

use crate::evaluator::{EvalHost};
use crate::evaluator::eval_host::Flow; 
use rune_ast::Block;

pub fn eval_block_flow<H: EvalHost>(host: &mut H, block: &Block) -> Flow {
    let mut last = Flow::Value(crate::runtime::value::Value::Unit);

    for stmt in &block.stmts {
        let flow = crate::evaluator::eval_stmt::eval_stmt(host, stmt);

        match &flow {
            Flow::Value(_) => {
                last = flow;
            }
            Flow::Break | Flow::Continue | Flow::Return(_) => {
                // propagate immediately
                return flow;
            }
        }
    }

    last
}
