// IR module: data structures for SSA intermediate representation
pub mod ir;
pub mod opcode;
pub mod function;

pub use ir::{
    ProgramIR, FunctionIR, BasicBlock, Block,
    Instruction, Instr,
    Value, ValueId, BlockId,
    CallTarget, MatchArm,
    Flow,
};
pub use opcode::Opcode;
pub use function::{IRFunction, IRValue};
