// ============================================
// rune-ir/src/ir.rs — Minimal SSA IR
// ============================================
use rune_ast::Pattern;

pub type ValueId = u32;
pub type BlockId = u32;

#[derive(Debug, Clone, PartialEq)]
pub enum Value {
    Number(f64),
    String(String),
    Bool(bool),
    Unit,

    Tuple(Vec<Value>),
    List(Vec<Value>),  

    EnumInstance {
        enum_name: String,
        variant: String,
        args: Vec<Value>,
    },

    StructInstance {
        name: String,
        fields: Vec<(String, Value)>,
    },

     Map(std::collections::HashMap<String, Value>), 
}

// Mirrors rune_evaluator::value::Value's Display impl so string
// interpolation/concatenation (`"" + id + ":" + name`, in the SSA
// compiler's lowering of `"{id}:{name}"`) formats numbers/strings/etc.
// identically regardless of which of the two engines produced them.
impl std::fmt::Display for Value {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Value::Number(n) => write!(f, "{}", n),
            Value::Bool(b) => write!(f, "{}", b),
            Value::String(s) => write!(f, "{}", s),
            Value::Unit => write!(f, "()"),

            Value::Tuple(items) | Value::List(items) => {
                let (open, close) = if matches!(self, Value::Tuple(_)) { ("(", ")") } else { ("[", "]") };
                write!(f, "{}", open)?;
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", item)?;
                }
                write!(f, "{}", close)
            }

            Value::StructInstance { name, fields } => {
                write!(f, "{} {{ ", name)?;
                for (i, (k, v)) in fields.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}: {}", k, v)?;
                }
                write!(f, " }}")
            }

            Value::EnumInstance { enum_name, variant, args } => {
                write!(f, "{}::{}(", enum_name, variant)?;
                for (i, v) in args.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", v)?;
                }
                write!(f, ")")
            }

            Value::Map(map) => {
                write!(f, "map {{ ")?;
                for (i, (k, v)) in map.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}: {}", k, v)?;
                }
                write!(f, " }}")
            }
        }
    }
}

// The callee of an Instr::Call.
//
// There's no first-class function/closure value in this IR's Value type,
// so a plain named call (`foo(1, 2)` where `foo` isn't a local variable)
// is resolved by NAME at the SSA-compiler level rather than by lowering
// `foo` as an expression (which would try -- and fail -- to LoadLocal a
// runtime variable called "foo" that was never StoreLocal'd). See
// compiler.rs's Expr::Call lowering and ir_vm.rs's Instr::Call handling.
#[derive(Debug, Clone)]
pub enum CallTarget {
    Named(String),
    // Indirect call through an already-computed value (e.g. a variable
    // holding a lambda). Represented so the IR can at least be built for
    // this case, but IrVM has no runtime function/closure Value to call
    // through yet, so this reports clearly rather than silently no-oping.
    Value(ValueId),
}

// One arm of a Match instruction.
//
// `guard` and `body` are self-contained sub-blocks, NOT part of the
// enclosing function's Vec<Block> -- they are only executed (via
// IrVM::run_block) once this arm's pattern has already matched the
// scrutinee at runtime. This is what lets each arm's pattern-bound
// variables (e.g. `x` in `A { x } => x * 2`) be extracted (via
// FieldAccess/TupleExtract/... emitted by bind_pattern at the top of
// each sub-block) and referenced correctly, and lets differently-shaped
// arms coexist without one arm's extraction code panicking when a
// different arm's pattern is the one that actually matched. See
// compiler.rs's Expr::Match lowering and ir_vm.rs's Instr::Match handling.
#[derive(Debug, Clone)]
pub struct MatchArm {
    pub pattern: Pattern,
    pub guard: Option<Block>,
    pub body: Block,
}

#[derive(Debug, Clone)]
pub struct Block {
    pub id: BlockId,
    pub instrs: Vec<Instr>,
}

#[derive(Debug, Clone)]
pub enum Instr {
    Const { dst: ValueId, value: Value },

    LoadLocal { dst: ValueId, name: String },
    StoreLocal { name: String, src: ValueId },

    Unary { dst: ValueId, op: String, src: ValueId },
    Binary { dst: ValueId, op: String, lhs: ValueId, rhs: ValueId },

    Call { dst: ValueId, func: CallTarget, args: Vec<ValueId> },

    // Reads the value passed as the `index`-th argument of the function
    // currently executing. Emitted once per parameter at the top of
    // compile_fn (see compiler.rs), immediately followed by the same
    // bind_pattern() logic already used for `let` so tuple/struct/etc.
    // parameter patterns are destructured for free.
    Param { dst: ValueId, index: usize },

    FieldAccess { dst: ValueId, base: ValueId, field: String },
    NamespaceAccess { dst: ValueId, base: ValueId, item: String },

    Index { dst: ValueId, arr: ValueId, index: ValueId },

    StructInit {
        dst: ValueId,
        name: String,
        fields: Vec<(String, ValueId)>
    },

    StructUpdate {
        dst: ValueId,
        base: ValueId,
        updates: Vec<(String, ValueId)>,
    },

    VariantInit {
        dst: ValueId,
        enum_name: String,
        variant: String,
        fields: Vec<(String, ValueId)>,
    },

    Array {
        dst: ValueId,
        items: Vec<ValueId>,
    },

    Match {
        dst: ValueId,
        scrutinee: ValueId,
        arms: Vec<MatchArm>,
    },

    Tuple {
        dst: ValueId,
        items: Vec<ValueId>
    },


    TupleExtract {
        dst: ValueId,
        tuple: ValueId,
        index: usize
    },

    MapInit {
        dst: ValueId,
        entries: Vec<(String, ValueId)>,
    },

    MapAccess {
        dst: ValueId,
        map: ValueId,
        key: String
    },

  FieldStore {
        base: ValueId,
        field: String,
        src: ValueId,
    },

    IndexStore {
        arr: ValueId,
        index: ValueId,
        src: ValueId,
    },
    
    Return(ValueId),
}

#[derive(Debug, Clone)]
pub struct FunctionIR {
    pub name: String,
    pub blocks: Vec<Block>,
    pub locals: std::collections::HashMap<String, ValueId>,
}

#[derive(Debug, Clone)]

// Control flow for statement lowering
#[derive(Debug, Clone)]
pub enum Flow {
    Value(ValueId),           // Statement produces a value
    Break,                    // Break from loop
    Continue,                 // Continue to next loop iteration
    Return(ValueId),          // Return from function
}

pub struct ProgramIR {
    pub functions: Vec<FunctionIR>,
}

impl ProgramIR {
    pub fn new() -> Self {
        Self { functions: vec![] }
    }
}

impl Value {
    pub fn unwrap_number(&self) -> f64 {
        match self {
            Value::Number(n) => *n,
            other => panic!("Expected number, got {:?}", other),
        }
    }

    pub fn unwrap_bool(&self) -> bool {
        match self {
            Value::Bool(b) => *b,
            other => panic!("Expected bool, got {:?}", other),
        }
    }

    pub fn unwrap_string(&self) -> &str {
        match self {
            Value::String(s) => s,
            other => panic!("Expected string, got {:?}", other),
        }
    }
}
