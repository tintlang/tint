// Core SSA compiler orchestrator
use crate::ir::*;
use crate::builder::IrBuilder;
use super::lower_stmt;
use super::lower_expr;
use super::bind_pattern;
use rune_ast::{Program, Item, FnDecl};
use std::collections::HashMap;

pub struct SsaCompiler {
    builder: IrBuilder,
}

impl SsaCompiler {
    pub fn new() -> Self {
        Self {
            builder: IrBuilder::new(),
        }
    }

    pub fn compile_program(&mut self, prog: &Program) -> ProgramIR {
        let mut out = ProgramIR::new();

        for item in &prog.items {
            if let Item::Fn(f) = item {
                out.functions.push(self.compile_fn(f));
            }
        }

        out
    }

    pub fn compile_fn(&mut self, f: &FnDecl) -> FunctionIR {
        let mut block = self.builder.new_block();
        let mut locals = HashMap::new();

        // Bind parameters: emit one Param instruction per parameter (reads
        // the index-th argument the IR VM was called with -- see
        // Instr::Param / IrVM::run), then reuse the existing compile-time
        // bind_pattern() to destructure it into `locals`. bind_pattern
        // already handles Ident, Tuple, Struct, Group and Map patterns
        // (used previously only for `let`), so tuple/struct parameter
        // patterns are supported for free.
        for (i, param) in f.params.iter().enumerate() {
            let pv = self.builder.emit_param(&mut block, i);
            bind_pattern::bind_pattern(
                &param.pattern,
                pv,
                &mut locals,
                &mut block,
                &self.builder,
            );
        }

        match &f.body {
            // A block body's return value is whatever its LAST statement
            // evaluates to when that statement is a bare expression (no
            // explicit `return`) -- the same "implicit tail expression"
            // convention the tree-walking evaluator already implements in
            // eval_block_flow (see rune-evaluator/src/eval_block.rs: the
            // block's Flow is just whatever the last statement's Flow
            // was). The SSA compiler previously had no equivalent: plain
            // Stmt::Expr statements were lowered via lower_stmt(), which
            // computes the ValueId and then DISCARDS it, so a function
            // whose body was just `match x { ... }` with no `return`
            // keyword always fell through to an implicit Value::Unit.
            // An explicit `return expr;` still short-circuits (and, since
            // this IR has no branch instructions, is only meaningful as
            // a performance win on loop exit, which we don't do yet anyway).
            rune_ast::FnBody::Block(body) => {
                for stmt in &body.stmts {
                    let flow = lower_stmt::lower_stmt(
                        self,
                        stmt,
                        &mut block,
                        &mut locals,
                    );
                    if let crate::ir::Flow::Return(v) = flow {
                        self.builder.emit_return(&mut block, v);
                        break;
                    }
                }
            }
            rune_ast::FnBody::Expr(body) => {
                let v = lower_expr::lower_expr(self, body, &mut block, &mut locals);
                self.builder.emit_return(&mut block, v);
            }
        }

        FunctionIR {
            id: f.name.clone(),
            block,
            value_count: self.builder.value_counter,
        }
    }

    pub fn builder(&self) -> &IrBuilder {
        &self.builder
    }

    pub fn builder_mut(&mut self) -> &mut IrBuilder {
        &mut self.builder
    }
}
