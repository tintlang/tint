// Pattern binding for IR compilation
// Converts source-level patterns into IR instructions that destructure values into locals

use crate::ir::*;
use crate::builder::IrBuilder;
use crate::compiler::SsaCompiler;
use rune_ast::{Pattern, Expr};
use std::collections::HashMap;

pub fn bind_pattern(
    pattern: &Pattern,
    value: ValueId,
    locals: &mut HashMap<String, ValueId>,
    block: &mut Block,
    builder: &IrBuilder,
) {
    match pattern {
        // Simple identifier binding: let x = value
        Pattern::Ident(name) => {
            locals.insert(name.clone(), value);
        }

        // Tuple pattern: let (a, b) = value
        // For now, simplified: emit tuple destructure instructions
        Pattern::Tuple(patterns) => {
            for (idx, p) in patterns.iter().enumerate() {
                let extracted = builder.emit_tuple_extract(block, value, idx);
                bind_pattern(p, extracted, locals, block, builder);
            }
        }

        // Struct pattern: let Point { x, y } = value
        // Destructure struct fields
        Pattern::Struct { fields, .. } => {
            for (field_name, sub_pattern) in fields {
                let extracted = builder.emit_field_load(block, value, field_name.clone());
                bind_pattern(sub_pattern, extracted, locals, block, builder);
            }
        }

        // Group pattern: let (p) = value (pass through to inner pattern)
        Pattern::Group(p) => {
            bind_pattern(p, value, locals, block, builder);
        }

        // Map pattern: let { key1, key2 } = value
        Pattern::Map(fields) => {
            for (key, sub_pattern) in fields {
                let extracted = builder.emit_map_access(block, value, key.clone());
                bind_pattern(sub_pattern, extracted, locals, block, builder);
            }
        }

        // Rest pattern: let [a, ..rest, b] (simplified)
        Pattern::Rest(_) => {
            // Placeholder: rest patterns are complex and simplified here
        }

        // Literal pattern: let 42 = value (not supported for binding)
        Pattern::Literal(_) => {
            // Literal patterns don't bind, only match
        }

        // Path pattern (e.g. None, Some pattern)
        Pattern::Path(_) => {
            // Simplified: treat as identifier for now
        }

        // Wildcard pattern: let _ = value (no binding)
        Pattern::Wildcard => {
            // No binding needed
        }
    }
}

// Handle assignment to patterns on the left-hand side
pub fn lower_assignment_lhs(
    compiler: &mut SsaCompiler,
    lhs: &Expr,
    rhs_val: ValueId,
    block: &mut Block,
    locals: &mut HashMap<String, ValueId>,
) {
    use super::lower_expr;

    match lhs {
        // Simple identifier assignment: x = value
        Expr::Ident(name) => {
            locals.insert(name.clone(), rhs_val);
            compiler.builder_mut().emit_store(block, name.clone(), rhs_val);
        }

        // Field assignment: obj.field = value
        Expr::Field { expr, field } => {
            let obj_val = lower_expr::lower_expr(compiler, expr, block, locals);
            compiler.builder_mut().emit_field_store(block, obj_val, field.clone(), rhs_val);
        }

        // Index assignment: arr[idx] = value
        Expr::Index { expr, index } => {
            let arr_val = lower_expr::lower_expr(compiler, expr, block, locals);
            let idx_val = lower_expr::lower_expr(compiler, index, block, locals);
            compiler.builder_mut().emit_index_store(block, arr_val, idx_val, rhs_val);
        }

        // Tuple element assignment: (a, b).0 = value
        Expr::TupleIndex { expr, index } => {
            let tuple_val = lower_expr::lower_expr(compiler, expr, block, locals);
            compiler.builder_mut().emit_tuple_store(block, tuple_val, *index, rhs_val);
        }

        // Other expressions are invalid LHS targets
        _ => {
            panic!("Invalid assignment LHS");
        }
    }
}
