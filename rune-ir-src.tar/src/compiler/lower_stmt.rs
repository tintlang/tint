// Statement lowering to SSA IR
use crate::ir::*;
use super::compiler::SsaCompiler;
use super::lower_expr;
use super::bind_pattern;
use rune_ast::{Stmt, Pattern};
use std::collections::HashMap;

pub fn lower_stmt(
    compiler: &mut SsaCompiler,
    stmt: &Stmt,
    block: &mut Block,
    locals: &mut HashMap<String, ValueId>,
) -> Flow {
    match stmt {
        Stmt::Let {
            pattern,
            ty: _,
            init,
            span: _,
        } => {
            // Determine the initialization value
            let value = match init {
                rune_ast::LetInit::Assign(expr) => {
                    lower_expr::lower_expr(compiler, expr, block, locals)
                }
                rune_ast::LetInit::Rune(expr) => {
                    lower_expr::lower_expr(compiler, expr, block, locals)
                }
            };

            // Bind the pattern with the computed value
            bind_pattern::bind_pattern(pattern, value, locals, block, compiler.builder());
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }

        Stmt::Assign { lhs, rhs, span: _ } => {
            let rhs_val = lower_expr::lower_expr(compiler, rhs, block, locals);
            bind_pattern::lower_assignment_lhs(compiler, lhs, rhs_val, block, locals);
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }

        Stmt::CompoundAssign { name, op, expr, span: _ } => {
            let current = locals.get(name).cloned().unwrap_or_else(|| {
                compiler.builder().emit_load(block, name.clone())
            });
            let rhs = lower_expr::lower_expr(compiler, expr, block, locals);

            let result = match op.as_str() {
                "+=" => compiler.builder().emit_add(block, current, rhs),
                "-=" => compiler.builder().emit_sub(block, current, rhs),
                "*=" => compiler.builder().emit_mul(block, current, rhs),
                "/=" => compiler.builder().emit_div(block, current, rhs),
                _ => panic!("Unknown compound operator: {}", op),
            };

            compiler.builder().emit_store(block, name.clone(), result);
            locals.insert(name.clone(), result);
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }

        Stmt::Expr(expr) => {
            let val = lower_expr::lower_expr(compiler, expr, block, locals);
            Flow::Value(val)
        }

        Stmt::If {
            cond,
            then,
            else_,
            span: _,
        } => {
            // For now, we'll evaluate the condition and return the then-block value
            let _cond_val = lower_expr::lower_expr(compiler, cond, block, locals);
            let mut result = Flow::Value(compiler.builder().emit_const(block, Value::Unit));

            for stmt in &then.stmts {
                result = lower_stmt(compiler, stmt, block, locals);
            }

            if let Some(else_block) = else_ {
                let mut else_result = Flow::Value(compiler.builder().emit_const(block, Value::Unit));
                for stmt in &else_block.stmts {
                    else_result = lower_stmt(compiler, stmt, block, locals);
                }
                // Merge the results (simplified: just use then for now)
            }

            result
        }

        Stmt::While { cond: _, body, span: _ } => {
            // Loop lowering: simplified, just execute once for now
            for stmt in &body.stmts {
                lower_stmt(compiler, stmt, block, locals)?;
            }
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }

        Stmt::Loop { body, span: _ } => {
            // Infinite loop handling
            for stmt in &body.stmts {
                let flow = lower_stmt(compiler, stmt, block, locals);
                if matches!(flow, Flow::Break | Flow::Continue | Flow::Return(_)) {
                    return flow;
                }
            }
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }

        Stmt::Break(_) => Flow::Break,
        Stmt::Continue(_) => Flow::Continue,
        Stmt::Return(expr, _) => {
            let val = lower_expr::lower_expr(compiler, expr, block, locals);
            Flow::Return(val)
        }

        Stmt::Match {
            expr: _,
            arms: _,
            span: _,
        } => {
            // Match lowering: simplified
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }

        Stmt::For {
            var: _,
            start: _,
            end: _,
            body,
            span: _,
        } => {
            // For loop lowering: simplified
            for stmt in &body.stmts {
                lower_stmt(compiler, stmt, block, locals)?;
            }
            Flow::Value(compiler.builder().emit_const(block, Value::Unit))
        }
    }
}
