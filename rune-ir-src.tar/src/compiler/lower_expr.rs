// Expression lowering to SSA IR
use crate::ir::*;
use crate::dbg_println;
use super::compiler::SsaCompiler;
use rune_ast::{Expr, StringPart};
use std::collections::HashMap;

pub fn lower_expr(
    compiler: &mut SsaCompiler,
    expr: &Expr,
    block: &mut Block,
    locals: &mut HashMap<String, ValueId>,
) -> ValueId {
    match expr {
        // NUMBER: 42
        Expr::Number(n, _) => {
            let parsed = n.parse::<f64>().unwrap_or(0.0);
            compiler.builder().emit_const(block, Value::Number(parsed))
        }

        // STRING: "hello"
        Expr::String(s, _) => {
            compiler.builder().emit_const(block, Value::String(s.clone()))
        }

        // STRING TEMPLATE: f"x={x}"
        Expr::Template { parts, .. } => {
            let mut result = String::new();
            for part in parts {
                match part {
                    StringPart::Literal(s) => result.push_str(s),
                    StringPart::Expr(_e) => {
                        result.push_str("<expr>");
                    }
                }
            }
            compiler.builder().emit_const(block, Value::String(result))
        }

        // BOOL: true/false
        Expr::Bool(b, _) => {
            compiler.builder().emit_const(block, Value::Bool(*b))
        }

        // UNIT: ()
        Expr::Unit(_) => {
            compiler.builder().emit_const(block, Value::Unit)
        }

        // IDENT: x
        Expr::Ident(name, _) => {
            if let Some(&vid) = locals.get(name) {
                vid
            } else {
                compiler.builder().emit_load(block, name.clone())
            }
        }

        // BINARY OP: a + b, a < b, etc.
        Expr::BinOp {
            left,
            op,
            right,
            span: _,
        } => {
            let l = lower_expr(compiler, left, block, locals);
            let r = lower_expr(compiler, right, block, locals);

            match op.as_str() {
                "+" => compiler.builder().emit_add(block, l, r),
                "-" => compiler.builder().emit_sub(block, l, r),
                "*" => compiler.builder().emit_mul(block, l, r),
                "/" => compiler.builder().emit_div(block, l, r),
                "%" => compiler.builder().emit_mod(block, l, r),
                "==" => compiler.builder().emit_eq(block, l, r),
                "!=" => compiler.builder().emit_ne(block, l, r),
                "<" => compiler.builder().emit_lt(block, l, r),
                "<=" => compiler.builder().emit_le(block, l, r),
                ">" => compiler.builder().emit_gt(block, l, r),
                ">=" => compiler.builder().emit_ge(block, l, r),
                "&&" => compiler.builder().emit_and(block, l, r),
                "||" => compiler.builder().emit_or(block, l, r),
                _ => panic!("Unknown operator: {}", op),
            }
        }

        // UNARY OP: -x, !x
        Expr::UnaryOp { op, expr: e, span: _ } => {
            let v = lower_expr(compiler, e, block, locals);
            match op.as_str() {
                "-" => compiler.builder().emit_neg(block, v),
                "!" => compiler.builder().emit_not(block, v),
                _ => panic!("Unknown unary operator: {}", op),
            }
        }

        // FIELD ACCESS: obj.field
        Expr::Field { target, field, .. } => {
            let base = lower_expr(compiler, target, block, locals);
            compiler.builder().emit_field_load(block, base, field.clone())
        }

        // INDEX ACCESS: arr[i]
        Expr::Index { target, index, .. } => {
            let base = lower_expr(compiler, target, block, locals);
            let idx = lower_expr(compiler, index, block, locals);
            compiler.builder().emit_index_load(block, base, idx)
        }

        // FUNCTION CALL: func(args)
        Expr::Call { func, args, .. } => {
            match func.as_ref() {
                Expr::Ident(name, _) => {
                    let arg_vals: Vec<_> = args
                        .iter()
                        .map(|arg| lower_expr(compiler, arg, block, locals))
                        .collect();
                    compiler.builder().emit_call(block, name.clone(), arg_vals)
                }
                _ => panic!("Complex function expressions not yet supported"),
            }
        }

        // STRUCT INIT: Point { x: 1, y: 2 }
        Expr::StructInit { name, fields, .. } => {
            let mut lowered = Vec::new();
            for field in fields {
                let v = lower_expr(compiler, &field.value, block, locals);
                lowered.push((field.name.clone(), v));
            }
            compiler.builder().emit_struct_init(block, name.clone(), lowered)
        }

        // ENUM VARIANT: Ok(value)
        Expr::EnumVariant { enum_name, variant, args, .. } => {
            let arg_vals: Vec<_> = args
                .iter()
                .map(|arg| lower_expr(compiler, arg, block, locals))
                .collect();
            compiler.builder().emit_enum_variant(
                block,
                enum_name.clone(),
                variant.clone(),
                arg_vals,
            )
        }

        // ARRAY: [a, b, c]
        Expr::Array { items, .. } => {
            let vals = items
                .iter()
                .map(|e2| lower_expr(compiler, e2, block, locals))
                .collect::<Vec<_>>();
            compiler.builder().emit_array(block, vals)
        }

        // TUPLE: (a,b,c)
        Expr::Tuple { items, .. } => {
            let vals = items
                .iter()
                .map(|e2| lower_expr(compiler, e2, block, locals))
                .collect::<Vec<_>>();
            compiler.builder().emit_tuple(block, vals)
        }

        // TUPLE INDEX: v.0, v.1 , v.2
        Expr::TupleIndex { target, index, .. } => {
            let base = lower_expr(compiler, target, block, locals);
            compiler.builder().emit_tuple_extract(block, base, *index)
        }

        // MAP: {"key": value, ...}
        Expr::MapInit { entries, .. } => {
            let mut lowered = Vec::new();
            for (k, e) in entries {
                let id = lower_expr(compiler, e, block, locals);
                lowered.push((k.clone(), id));
            }
            compiler.builder().emit_map_init(block, lowered)
        }

        // NAMED ARG — cannot be lowered outside call
        Expr::NamedArg { name, .. } => {
            panic!("Named argument `{}` cannot appear as bare expression", name);
        }

        // Lambda: TODO
        Expr::Lambda { .. } => {
            dbg_println!("TODO: lambda lowering");
            compiler.builder().emit_const(block, Value::Unit)
        }

        // Match expression: simplified
        Expr::Match { .. } => {
            compiler.builder().emit_const(block, Value::Unit)
        }

        // Paren: (expr)
        Expr::Paren(e, _) => lower_expr(compiler, e, block, locals),

        // Any other expression type
        _ => {
            dbg_println!("Unhandled expression type");
            compiler.builder().emit_const(block, Value::Unit)
        }
    }
}
