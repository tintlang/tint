// =============================================================
// SSA Optimization Passes (compatible with current RuneIR)
// =============================================================

use crate::ir::{ProgramIR, FunctionIR, Block, Instr, Value};

// =============================================================
// PUBLIC ENTRY POINT
// =============================================================
pub fn optimize(prog: &mut ProgramIR) {
    for f in &mut prog.functions {
        optimize_function(f);
    }
}

// =============================================================
// OPTIMIZE ONE FUNCTION
// =============================================================
fn optimize_function(func: &mut FunctionIR) {
    let mut changed = true;

    while changed {
        changed = false;

        changed |= constant_folding(func);
        changed |= dead_code_elimination(func);
    }
}

// =============================================================
// CONSTANT FOLDING
// =============================================================
fn constant_folding(func: &mut FunctionIR) -> bool {
    let mut changed = false;

    // 1) Collect const values
    use std::collections::HashMap;
    let mut const_map: HashMap<u32, Value> = HashMap::new();

    for block in &func.blocks {
        for instr in &block.instrs {
            if let Instr::Const { dst, value } = instr {
                const_map.insert(*dst, value.clone());
            }
        }
    }

    // 2) Fold binary ops
    for block in &mut func.blocks {
        for instr in &mut block.instrs {
            let original = std::mem::replace(instr, Instr::Return(0));

            *instr = match original {
                Instr::Binary { dst, op, lhs, rhs } => {
                    let lv = const_map.get(&lhs);
                    let rv = const_map.get(&rhs);

                    if let (Some(Value::Number(a)), Some(Value::Number(b))) = (lv, rv) {
                        let folded = match op.as_str() {
                            "+" => Some(a + b),
                            "-" => Some(a - b),
                            "*" => Some(a * b),
                            "/" => Some(a / b),
                            _ => None,
                        };

                        if let Some(result) = folded {
                            const_map.insert(dst, Value::Number(result));
                            changed = true;

                            Instr::Const {
                                dst,
                                value: Value::Number(result),
                            }
                        } else {
                            // preserve original if unknown op
                            Instr::Binary { dst, op, lhs, rhs }
                        }
                    } else {
                        // cannot fold (not both consts)
                        Instr::Binary { dst, op, lhs, rhs }
                    }
                }

                other => other,
            };
        }
    }

    changed
}

// =============================================================
// DEAD CODE ELIMINATION (DCE)
// =============================================================
fn dead_code_elimination(func: &mut FunctionIR) -> bool {
    use std::collections::HashSet;

    let mut live: HashSet<u32> = HashSet::new();

    // Mark return values as live
    for block in &func.blocks {
        for instr in &block.instrs {
            if let Instr::Return(id) = instr {
                live.insert(*id);
            }
        }
    }

    // propagate liveness backwards
    let mut changed = true;
    while changed {
        changed = false;

        for block in &func.blocks {
            for instr in &block.instrs {
                for used in used_values(instr) {
                    if live.insert(used) {
                        changed = true;
                    }
                }
            }
        }
    }

    // remove dead instructions
    let mut removed = false;

    for block in &mut func.blocks {
        let before = block.instrs.len();

        block.instrs.retain(|instr| {
            match instr {
                Instr::Binary { dst, .. }
                | Instr::Unary { dst, .. }
                | Instr::Const { dst, .. } => live.contains(dst),

                _ => true, // keep load/store/return
            }
        });

        if block.instrs.len() != before {
            removed = true;
        }
    }

    removed
}

// Collect used ValueIds (register READS) from an instruction.
//
// This must list every operand of every variant. It previously only
// covered Binary/Unary/StoreLocal/Return, so dead_code_elimination's
// backward liveness scan never saw registers read by Tuple/Array/
// StructInit/StructUpdate/VariantInit/Match/TupleExtract/FieldAccess/
// Index/MapInit/MapAccess/FieldStore/IndexStore/Call — it then deleted
// their still-needed defining Const/Binary/Unary instructions as
// "dead", and the interpreter later panicked reading a register that
// was never allocated (e.g. "index out of bounds" building a Tuple
// whose element Consts had been stripped).
fn used_values(instr: &Instr) -> Vec<u32> {
    match instr {
        Instr::Const { .. } => vec![],
        Instr::LoadLocal { .. } => vec![],

        Instr::StoreLocal { src, .. } => vec![*src],
        Instr::Unary { src, .. } => vec![*src],
        Instr::Binary { lhs, rhs, .. } => vec![*lhs, *rhs],

        Instr::Call { func, args, .. } => {
            let mut v = args.clone();
            if let crate::ir::CallTarget::Value(id) = func {
                v.push(*id);
            }
            v
        }

        Instr::Param { .. } => vec![],

        Instr::FieldAccess { base, .. } => vec![*base],
        Instr::NamespaceAccess { base, .. } => vec![*base],
        Instr::Index { arr, index, .. } => vec![*arr, *index],

        Instr::StructInit { fields, .. } => {
            fields.iter().map(|(_, v)| *v).collect()
        }

        Instr::StructUpdate { base, updates, .. } => {
            let mut v = vec![*base];
            v.extend(updates.iter().map(|(_, id)| *id));
            v
        }

        Instr::VariantInit { fields, .. } => {
            fields.iter().map(|(_, v)| *v).collect()
        }

        Instr::Array { items, .. } => items.clone(),
        Instr::Tuple { items, .. } => items.clone(),

        Instr::TupleExtract { tuple, .. } => vec![*tuple],

        // Match arms now carry self-contained guard/body sub-blocks (see
        // ir.rs's MatchArm) rather than precomputed ValueIds in the
        // enclosing block. Liveness for the ENCLOSING block still needs
        // to know about any outer-block register those sub-blocks read
        // (e.g. a variable captured from before the match), so recurse
        // into their instructions too -- this also transitively handles
        // a Match nested inside another Match's arm.
        Instr::Match { scrutinee, arms, .. } => {
            let mut v = vec![*scrutinee];
            for arm in arms {
                if let Some(gb) = &arm.guard {
                    for i in &gb.instrs {
                        v.extend(used_values(i));
                    }
                }
                for i in &arm.body.instrs {
                    v.extend(used_values(i));
                }
            }
            v
        }

        Instr::MapInit { entries, .. } => {
            entries.iter().map(|(_, v)| *v).collect()
        }
        Instr::MapAccess { map, .. } => vec![*map],

        Instr::FieldStore { base, src, .. } => vec![*base, *src],
        Instr::IndexStore { arr, index, src, .. } => vec![*arr, *index, *src],

        Instr::Return(id) => vec![*id],
    }
}
