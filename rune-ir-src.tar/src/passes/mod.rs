// Passes module: IR transformation and optimization passes
pub mod ssa;
pub mod ssa_pass;

// Re-export key types from ssa module
pub use ssa::{Value as SsaValue, ValueKind, Instr, FunctionIR as SsaFunctionIR};
// Re-export optimization pass
pub use ssa_pass::run_ssa_pass;
