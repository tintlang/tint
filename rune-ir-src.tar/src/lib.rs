// Rune IR crate: SSA intermediate representation and compilation

pub mod compiler;
pub mod ir;
pub mod passes;
pub mod vm;
pub mod builder;

pub use compiler::SsaCompiler;
pub use ir::ProgramIR;
pub use passes::run_ssa_pass;
pub use vm::IrVM;
pub use builder::IrBuilder;

// Debug-only logging: on native targets this is exactly `println!`, so
// CLI/test output is unchanged. On wasm32 (no real stdout -- writing
// there panics instead of erroring) it's a no-op, since these are
// developer diagnostics, not program output (see rune-evaluator's
// output.rs for actual captured program output).
#[cfg(not(target_arch = "wasm32"))]
macro_rules! dbg_println {
    ($($arg:tt)*) => { println!($($arg)*) };
}
#[cfg(target_arch = "wasm32")]
macro_rules! dbg_println {
    ($($arg:tt)*) => { let _ = format_args!($($arg)*); };
}
pub(crate) use dbg_println;
