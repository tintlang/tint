use crate::dbg_println;
use crate::ir::*;
use rune_ast::{Pattern, PatternField};

pub struct IrVM {
    pub program: ProgramIR,
    // Named runtime locals (from `let`/StoreLocal), scoped to whichever
    // function is CURRENTLY executing -- call_function() swaps this out
    // for a fresh, empty map for the duration of a nested call and
    // restores the caller's afterward, so two functions using the same
    // variable name can't clobber each other.
    locals: std::collections::HashMap<String, Value>,
    // SSA value table, indexed by ValueId. ValueIds are allocated by a
    // single global counter shared across the WHOLE compiled program (see
    // IrBuilder), so two different functions never share an id -- but a
    // function called recursively (directly or through mutual calls)
    // reuses the exact same ids on every invocation, since it's compiled
    // only once. call_function() snapshots and restores this table around
    // a nested call so a recursive call can't clobber the caller's own
    // in-progress registers while it's running.
    values: Vec<Value>,

    // Stack of argument lists, one per currently-executing function
    // activation, so nested/recursive calls each see their own
    // Instr::Param reads. Match arm sub-blocks run via run_block()
    // without pushing here, since they execute inside the SAME function
    // activation as their enclosing block.
    param_stack: Vec<Vec<Value>>,
}

impl IrVM {
    pub fn new(program: ProgramIR) -> Self {
        Self {
            program,
            locals: Default::default(),
            values: vec![],
            param_stack: vec![],
        }
    }

    pub fn run(&mut self, entry: &str, args: &[Value]) -> Value {
        self.call_function(entry, args)
    }

    // Looks up `name` among the compiled program's top-level functions and
    // runs it with `args`, isolating the callee's named locals and SSA
    // value table from whatever the caller was in the middle of (see the
    // field comments on `locals`/`values` above). This is the single path
    // both the public `run()` entry point and Instr::Call go through, so
    // Rune-level function calls (`foo(1, 2)` inside another Rune function)
    // and the EvalHost-driven top-level call both behave identically.
    fn call_function(&mut self, name: &str, args: &[Value]) -> Value {
        // A handful of builtins (print/dbg/sqrt) exist only in the
        // tree-walking evaluator's call_builtin (rune-evaluator/src/call.rs)
        // -- they have no corresponding entry in `self.program.functions`,
        // since they're not user `fn` declarations. Compiled IR code still
        // calls them by name (Instr::Call/CallTarget::Named), so without
        // this they'd hit the "unknown function" panic below on the very
        // first `print(...)` a Rune program makes. Mirrored here rather
        // than routed through the evaluator, since IrVM has no EvalHost to
        // call into; output goes through the same capture buffer
        // (rune_evaluator::output) the tree-walker uses, so callers of
        // either engine retrieve it the same way.
        if let Some(result) = self.call_builtin(name, args) {
            return result;
        }

        let Some(func) = self.program.functions.iter().find(|f| f.name == name).cloned() else {
            panic!(
                "Call to unknown function '{}': not found in the compiled IR program \
                 (only top-level `fn` declarations are callable from IR)",
                name
            );
        };

        let values_snapshot = self.values.clone();
        let locals_snapshot = std::mem::take(&mut self.locals);

        let result = self.run_function(&func, args);

        self.values = values_snapshot;
        self.locals = locals_snapshot;

        result
    }

    /// Returns Some(result) for a handful of builtins not present as
    /// compiled IR functions (see call_function's comment); None means
    /// "not a builtin, keep looking in program.functions".
    fn call_builtin(&mut self, name: &str, args: &[Value]) -> Option<Value> {
        match name {
            "print" => {
                for a in args {
                    rune_evaluator::output::emit(&format!("{}", a));
                }
                Some(Value::Unit)
            }
            "dbg" => {
                rune_evaluator::output::emit(&format!("DBG: {:?}", args));
                Some(Value::Unit)
            }
            "sqrt" => {
                let x = args.get(0).map(|v| v.unwrap_number()).unwrap_or(0.0);
                Some(Value::Number(x.sqrt()))
            }
            _ => None,
        }
    }

    fn alloc_value(&mut self, id: ValueId, v: Value) {
        if id as usize >= self.values.len() {
            self.values.resize((id + 1) as usize, Value::Unit);
        }
        self.values[id as usize] = v;
    }

    fn get_value(&self, id: ValueId) -> Value {
        self.values[id as usize].clone()
    }

    fn run_function(&mut self, func: &FunctionIR, args: &[Value]) -> Value {
        self.param_stack.push(args.to_vec());
        // Run only block 0 for now
        let result = self.run_block(&func.blocks[0]);
        self.param_stack.pop();
        result
    }

    // Executes a flat sequence of instructions and returns the value of
    // its Instr::Return (or Value::Unit if it falls off the end without
    // one). Used both for a function's top-level block and for the
    // guard/body sub-blocks of a Match arm (see Instr::Match below) --
    // those sub-blocks are NOT part of any FunctionIR.blocks list, so they
    // are only ever reached by an explicit run_block() call once their
    // arm's pattern has already matched.
    fn run_block(&mut self, block: &Block) -> Value {
        for instr in &block.instrs {
            match instr {
                Instr::Const { dst, value } => {
                    self.alloc_value(*dst, value.clone());
                }

                Instr::LoadLocal { dst, name } => {
                    let v = self.locals.get(name)
                        .unwrap_or_else(|| panic!("Undefined variable {}", name))
                        .clone();

                    self.alloc_value(*dst, v);
                }

                Instr::StoreLocal { name, src } => {
                    let v = self.get_value(*src);
                    self.locals.insert(name.clone(), v);
                }

                Instr::Unary { dst, op, src } => {
                    let v = self.get_value(*src).unwrap_number();
                    let out = match op.as_str() {
                        "-" => -v,
                        "+" =>  v,
                        _ => panic!("Unknown unary op {}", op),
                    };
                    self.alloc_value(*dst, Value::Number(out));
                }

                Instr::Binary { dst, op, lhs, rhs } => {
                    let l = self.get_value(*lhs);
                    let r = self.get_value(*rhs);

                    // "+" doubles as string concatenation whenever either
                    // side is a String (this is how the SSA compiler lowers
                    // string interpolation, e.g. `"{id}:{name}"` becomes
                    // `"" + id + ":" + name`); comparisons use Value's
                    // Display/PartialEq so they work on any value kind, not
                    // just numbers.
                    let out = match op.as_str() {
                        "+" if matches!(l, Value::String(_)) || matches!(r, Value::String(_)) => {
                            Value::String(format!("{}{}", l, r))
                        }
                        "+" => Value::Number(l.unwrap_number() + r.unwrap_number()),
                        "-" => Value::Number(l.unwrap_number() - r.unwrap_number()),
                        "*" => Value::Number(l.unwrap_number() * r.unwrap_number()),
                        "/" => Value::Number(l.unwrap_number() / r.unwrap_number()),
                        "==" => Value::Bool(l == r),
                        "!=" => Value::Bool(l != r),
                        "<" => Value::Bool(l.unwrap_number() < r.unwrap_number()),
                        ">" => Value::Bool(l.unwrap_number() > r.unwrap_number()),
                        "<=" => Value::Bool(l.unwrap_number() <= r.unwrap_number()),
                        ">=" => Value::Bool(l.unwrap_number() >= r.unwrap_number()),
                        "&&" => Value::Bool(l.unwrap_bool() && r.unwrap_bool()),
                        "||" => Value::Bool(l.unwrap_bool() || r.unwrap_bool()),
                        _ => panic!("Unknown binary op {}", op),
                    };

                    self.alloc_value(*dst, out);
                }

                Instr::Call { dst, func, args } => {
                    let arg_vals: Vec<Value> = args.iter().map(|id| self.get_value(*id)).collect();

                    let result = match func {
                        CallTarget::Named(name) => self.call_function(name, &arg_vals),
                        CallTarget::Value(_) => {
                            dbg_println!(
                                "WARNING: indirect calls (calling a value, e.g. a stored \
                                 lambda) are not supported yet, returning unit"
                            );
                            Value::Unit
                        }
                    };

                    self.alloc_value(*dst, result);
                }

                Instr::Param { dst, index } => {
                    let v = self.param_stack.last()
                        .and_then(|args| args.get(*index))
                        .cloned()
                        // Missing argument (e.g. a default-parameter call
                        // site with fewer args than params, not yet
                        // supported) -> Unit rather than a panic.
                        .unwrap_or(Value::Unit);
                    self.alloc_value(*dst, v);
                }

                Instr::FieldAccess { dst, base, field } => {
                    let base_v = self.get_value(*base);
                    let v = match &base_v {
                        Value::StructInstance { fields, .. } => {
                            fields.iter()
                                .find(|(k, _)| k == field)
                                .map(|(_, v)| v.clone())
                                .unwrap_or_else(|| panic!(
                                    "Field `{}` not found on struct value {:?}", field, base_v
                                ))
                        }
                        Value::Map(m) => {
                            m.get(field).cloned().unwrap_or_else(|| panic!(
                                "Field `{}` not found on map value {:?}", field, base_v
                            ))
                        }
                        Value::EnumInstance { args, .. } => {
                            // Best-effort: enum "fields" aren't name-addressable in this
                            // Value shape (args is positional), so this only helps if
                            // there's exactly one arg (common for the tests we've seen).
                            args.first().cloned().unwrap_or_else(|| panic!(
                                "Field `{}` access on enum value with no args: {:?}", field, base_v
                            ))
                        }
                        other => panic!("Field access `.{}` on non-struct value: {:?}", field, other),
                    };
                    self.alloc_value(*dst, v);
                }

                Instr::NamespaceAccess { dst, .. } => {
                    dbg_println!("WARNING: namespace access not implemented");
                    self.alloc_value(*dst, Value::Unit);
                }

                Instr::Index { dst, arr, index } => {
                    let arr_v = self.get_value(*arr);
                    let idx_v = self.get_value(*index);
                    let idx = idx_v.unwrap_number() as usize;

                    let v = match &arr_v {
                        Value::List(items) => items.get(idx).cloned().unwrap_or_else(|| {
                            panic!("Index {} out of bounds (len {})", idx, items.len())
                        }),
                        Value::Tuple(items) => items.get(idx).cloned().unwrap_or_else(|| {
                            panic!("Index {} out of bounds (len {})", idx, items.len())
                        }),
                        other => panic!("Index access [{}] on non-indexable value: {:?}", idx, other),
                    };
                    self.alloc_value(*dst, v);
                }

                Instr::FieldStore { .. } => {
                    dbg_println!("WARNING: field store not implemented");
                }

                Instr::IndexStore { .. } => {
                    dbg_println!("WARNING: index store not implemented");
                }

                Instr::Match { dst, scrutinee, arms } => {
                    let scr = self.get_value(*scrutinee);
                    let mut chosen: Option<Value> = None;

                    for arm in arms {
                        if !pattern_matches(&scr, &arm.pattern) {
                            continue;
                        }
                        if let Some(gb) = &arm.guard {
                            if !self.run_block(gb).unwrap_bool() {
                                continue;
                            }
                        }
                        // Only the SELECTED arm's body sub-block is ever
                        // run, so its pattern-bound variables (extracted
                        // by bind_pattern at the top of that sub-block --
                        // see compiler.rs's Expr::Match lowering) are both
                        // correct (the actual matched field, not an
                        // unrelated outer variable) and safe (no other
                        // arm's differently-shaped extraction code runs
                        // against this scrutinee).
                        chosen = Some(self.run_block(&arm.body));
                        break;
                    }

                    let v = chosen.unwrap_or_else(|| {
                        panic!("No match arm matched value {:?}", scr)
                    });
                    self.alloc_value(*dst, v);
                }

                Instr::StructInit { dst, name, fields } => {
                    let resolved = fields.iter()
                        .map(|(k, id)| (k.clone(), self.get_value(*id)))
                        .collect();

                    self.alloc_value(*dst, Value::StructInstance {
                        name: name.clone(),
                        fields: resolved,
                    });
                }

                Instr::VariantInit { dst, enum_name, variant, fields } => {
                    let mut args = Vec::new();

                    for (_, src) in fields {
                        let v = self.get_value(*src);
                        args.push(v);
                    }

                    let v = Value::EnumInstance {
                        enum_name: enum_name.clone(),
                        variant: variant.clone(),
                        args,
                    };

                    self.alloc_value(*dst, v);
                }

                Instr::StructUpdate { dst, base, updates } => {
                    dbg_println!("WARNING: struct update not implemented, returning unit");
                    self.alloc_value(*dst, Value::Unit);
                }

                Instr::Tuple { dst, items } => {
                    // Сгенерировать runtime-значение tuple: Vec<Value>
                    let mut out = Vec::new();
                    for id in items {
                        out.push(self.get_value(*id));
                    }
                    self.alloc_value(*dst, Value::Tuple(out));
                }

                Instr::TupleExtract { dst, tuple, index } => {
                    let v = self.get_value(*tuple);
                    match v {
                        Value::Tuple(items) => {
                            let elem = items
                                .get(*index)
                                .unwrap_or_else(|| panic!("Tuple index {} out of bounds", index))
                                .clone();

                            self.alloc_value(*dst, elem);
                        }
                        other => panic!("TupleExtract on non-tuple value: {:?}", other),
                    }
                }

                Instr::Array { dst, items } => {
                    let mut out = Vec::new();
                    for id in items {
                        out.push(self.get_value(*id));
                    }
                    self.alloc_value(*dst, Value::List(out));
                }

                Instr::MapInit { dst, entries } => {
                    let mut m = std::collections::HashMap::new();
                    for (k, id) in entries {
                        m.insert(k.clone(), self.get_value(*id));
                    }
                    self.alloc_value(*dst, Value::Map(m));
                }

                Instr::MapAccess { dst, map, key } => {
                    let m = self.get_value(*map); 

                    match m {
                        Value::Map(ref hm) => {
                            // HashMap<String, Value>, key: String -> hm.get(&key)
                            if let Some(v) = hm.get(key) {    
                                self.alloc_value(*dst, v.clone()); 
                            } else {
                                panic!("Map missing key `{}`", key);
                            }
                        }
                        other => panic!("MapAccess on non-map: {:?}", other),
                    }
                }

                Instr::Return(id) => {
                    return self.get_value(*id);
                }
            }
        }

        Value::Unit
    }
}


// ─────────────────────────────────────────────────────────────
// Structural pattern matching for Instr::Match arm SELECTION only.
//
// This decides which arm's (already precomputed) result value to use;
// it does not bind pattern variables into scope. See the caveat above
// Instr::Match's handling in run_function.
// ─────────────────────────────────────────────────────────────
fn pattern_matches(value: &Value, pat: &Pattern) -> bool {
    match pat {
        Pattern::Wildcard(_) => true,
        Pattern::Ident(_, _) => true,
        Pattern::Mut { inner, .. } => pattern_matches(value, inner),
        Pattern::Typed { pat, .. } => pattern_matches(value, pat),

        Pattern::Number(s, _) => match value {
            Value::Number(n) => n.to_string() == *s,
            _ => false,
        },

        Pattern::String(s, _) => matches!(value, Value::String(v) if v == s),

        Pattern::Tuple(pats, _) => match value {
            Value::Tuple(items) => {
                pats.len() == items.len()
                    && pats.iter().zip(items.iter()).all(|(p, v)| pattern_matches(v, p))
            }
            _ => false,
        },

        Pattern::Struct { name, fields, .. } => match value {
            Value::StructInstance { name: vname, fields: vfields } => {
                vname == name && fields.iter().all(|pf| pattern_field_matches(pf, vfields))
            }
            // Enum variants with named fields (`A { x }`) are parsed as Pattern::Struct
            // too (see rune-parser); the enum's Value shape only keeps positional args,
            // so field sub-patterns beyond shorthand can't be checked here.
            Value::EnumInstance { variant, .. } => variant == name,
            _ => false,
        },

        Pattern::Variant { name, .. } => match value {
            Value::EnumInstance { variant, .. } => variant == name,
            _ => false,
        },

        // Map/Group patterns: not exercised by the current test suite.
        Pattern::Map { .. } | Pattern::Group { .. } => false,
    }
}

fn pattern_field_matches(pf: &PatternField, vfields: &[(String, Value)]) -> bool {
    match pf {
        PatternField::Shorthand { .. } => true,
        PatternField::Rest(_) => true,
        PatternField::Assign { field, pat, .. } => vfields
            .iter()
            .find(|(k, _)| k == field)
            .map(|(_, v)| pattern_matches(v, pat))
            .unwrap_or(false),
    }
}
