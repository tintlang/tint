// Register allocator skeleton for future optimization
// Currently provides naive register allocation for SSA values

use crate::ir::FunctionIR;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Reg(u8);

#[derive(Debug)]
pub struct AllocationResult {
    pub value_to_reg: std::collections::HashMap<u32, Reg>,
}

pub struct RegAlloc;

impl RegAlloc {
    pub fn allocate(func: &FunctionIR) -> AllocationResult {
        // Placeholder: naive allocation - each value gets unique register
        let mut map = std::collections::HashMap::new();

        let mut next = 0;
        for (id, _) in func.values.iter() {
            map.insert(*id, Reg(next));
            next += 1;
        }

        AllocationResult {
            value_to_reg: map,
        }
    }
}
